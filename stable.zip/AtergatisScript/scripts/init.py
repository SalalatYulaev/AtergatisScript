from AtergatisMain import (Atergatis, AtergatisLogger)
from var import *
import os, yaml
from colorama import init
from colorama import Fore, Back, Style



# Colorama
init()



class AtergatisInit(Atergatis):
	err_counter=0
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.selt_test()


	def selt_test(self):
		self._check_scripts()
		self._check_executor()
		self._check_upgrd_data_files()
		self._check_farmlist_dir()
		self.log._info(f"All checks done. {self.err_counter} ERRORS found.")
		self.log._info("="*50)


	def _check_scripts(self):
		print(Fore.RED, end='')
		if not os.path.exists(ATTACKS_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing check_attacks.py")
		if not os.path.exists(OVERRES_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing check_overres.py")
		if not os.path.exists(ADVENTURES_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing check_adventures.py")
		if not os.path.exists(D1_UPGRADE_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing dorf1_upgrade.py")
		if not os.path.exists(D2_UPGRADE_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing dorf2_upgrade.py")
		if not os.path.exists(ELEPHANTS_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing elephants_finder.py")
		if not os.path.exists(RASKAT_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing raskat.py")
		if not os.path.exists(SAVE_TROOPS_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing save_troops.py")
		if not os.path.exists(FARM_SCRIPT):
			self.log._info(f"Missing send_farm.py")
			self.err_counter += 1
		print(Fore.WHITE, end='')


	def _check_executor(self):
		for executor in EXECUTORS:
			for bat, script in executor.items():				
				self._create_executor(bat, script)


	def _create_executor(self, bat, script):
		text = f'''@echo off\n"python.exe" "{script}" %*\npause'''
		with open(bat, 'w') as f:
			f.write(text)
			self.log._debug(f"Updated  {bat}")


	def _check_upgrd_data_files(self):
		if not os.path.exists(DORF1_DATA_FILE):
			with open(DORF1_DATA_FILE, 'w') as f:
				f.write("Village name: 01\nTarget level: 10")
			self.log._debug(f"Created build_dorf1.txt")
		else:
			self.log._debug(f"Exists build_dorf1.txt")

		if not os.path.exists(DORF2_DATA_FILE):
			with open(DORF2_DATA_FILE, 'w') as f:
				f.write("01!\n26,10")
			self.log._debug(f"Created build_dorf2.txt")
		else:
			self.log._debug(f"Exists build_dorf2.txt")

		if not os.path.exists(RASKAT_FILE):
			with open(RASKAT_FILE, 'w') as f:
				f.write("From village:\t\t01\nTarget village ID:\t11111\nWaves:\t\t\t20\nHorses in wave:\t\t100\nCatas in wave:\t\t100")
			self.log._debug(f"Created raskat.txt")
		else:
			self.log._debug(f"Exists raskat.txt")

		if not os.path.exists(INFO_FILE):
			with open(INFO_FILE, 'w') as f:
				f.write("village_name: 01, overres, wh\nvillage_name: 01, attacks")
			self.log._debug("Created info.txt")
		else:
			self.log._debug("Exists info.txt")


	def _check_farmlist_dir(self):
		farmlist_dir = "farmlist\\"
		farm_list = farmlist_dir + "farmlist.yml"
		if not os.path.exists(farmlist_dir):
			os.makedirs(farmlist_dir)
			farmlist = {'03': [{'list_id': '14', 'list_name': '01'}, {'list_id': '47', 'list_name': '02'}]}
			with open(farm_list, 'w') as f:
				yaml.dump(farmlist, f)
			self.log._debug("Farmlist dir and template file created.")
		else:
			self.log._debug("Exists farmlist.yml")



if __name__ == '__main__':
	task = AtergatisInit(logfile=INIT_LOG,
		script_name='init',
		debug=True)