from AtergatisMain import Atergatis
from var import *
import os, yaml
from colorama import Fore, Back, Style



class AtergatisInit(Atergatis):
	err_counter=0
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.selt_test()


	def selt_test(self):
		self._check_scripts_and_data_files()
		self._check_executor()
		self.log._info(f"All checks done. {self.err_counter} ERRORS found.")
		self.log._info("="*50)


	def _check_scripts_and_data_files(self):
		print(Fore.RED, end='')
		if not os.path.exists(ATTACKS_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing check_attacks.py")
		if not os.path.exists(OVERRES_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing check_overres.py")
		if not os.path.exists(ADVENTURES_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing check_adventures.py")
		if not os.path.exists(D1_UPGRADE_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing dorf1_upgrade.py")
		if not os.path.exists(D2_UPGRADE_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing dorf2_upgrade.py")
		if not os.path.exists(ELEPHANTS_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing elephants_finder.py")
		if not os.path.exists(RASKAT_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing raskat.py")
		if not os.path.exists(SAVE_TROOPS_SCRIPT):
			self.err_counter += 1
			self.log._info(f"Missing save_troops.py")
		if not os.path.exists(FARM_SCRIPT):
			self.log._info(f"Missing send_farm.py")
			self.err_counter += 1
		if not os.path.exists(MAIN_TASKS_SCRIPT):
			self.log._info(f"Missing main_tasks.py")
			self.err_counter += 1
		if not os.path.exists(DORF1_DATA_FILE):
			self.log._info(f"Missing data_build_dorf1.yaml")
			self.err_counter += 1
		if not os.path.exists(DORF2_DATA_FILE):
			self.log._info(f"Missing data_build_dorf2.yaml")
			self.err_counter += 1
		if not os.path.exists(RASKAT_DATA_FILE):
			self.log._info(f"Missing data_raskat.yaml")
			self.err_counter += 1
		if not os.path.exists(TASKS_FILE):
			self.log._info(f"Missing data_tasks.yaml")
			self.err_counter += 1
		print(Fore.WHITE, end='')


	def _check_executor(self):
		for executor in EXECUTORS:
			for bat, script in executor.items():				
				self._create_executor(bat, script)


	def _create_executor(self, bat, script):
		text = f'''@echo off\n"python.exe" "{script}" %*\npause'''
		with open(bat, 'w') as f:
			f.write(text)
			self.log._debug(f"Updated  {bat}")



if __name__ == '__main__':
	task = AtergatisInit(logfile=INIT_LOG,
		script_name='init',
		debug=True)