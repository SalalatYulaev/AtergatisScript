import random
import time
import subprocess
import sys
import os
import asyncio
from datetime import datetime
from colorama import Fore, Back, Style
from var import *
from AtergatisMain import Atergatis




class Monitoring(Atergatis):
	# def __init__(self):
	# 	self.log._debug("Class Monitoring initialized")

	async def monitoring(self, mon_instance):
		self.log._debug(f"Started {mon_instance['name']} function")
		await asyncio.sleep(0.5)
		self.log._debug(mon_instance)		
		prev_ts = ''
		err_c = 0
		while True:
			prev_ts, err_c = self._mon_handler(prev_ts, err_c, mon_instance)
			self.log._debug(f"Error counter: {err_c}")
			await asyncio.sleep(MONITORING_SLEEP)


	def _mon_handler(self, prev_ts, err_c, mon_instance):
		self.log._debug(f"Started _mon_handler function")
		return self.check_file(prev_ts, err_c, **mon_instance)
			


	def check_file(self, prev_ts, err_c, file, name, script):
		self.log._debug(f"Started check_file function")
		if os.path.exists(file):
			try:
				with open(file) as f:
					data = f.read().split("\n")
				q_mass = []		
				ts = datetime.strftime(datetime.now(), "%H%M%S")
				for line in data:
					if line:
						line = line.strip()
						q_mass.append(line)
				last_ts = q_mass[-1]
				if prev_ts:
					if prev_ts == last_ts:
						print("RAVEN")
						err_c += 1
						print(Fore.YELLOW, end='')
						self.log._info(f"{name} ERROR conunter = {err_c}")
						print(Fore.WHITE, end='')
						if err_c >= 3:
							print(Fore.RED, end='')
							self.log._info(f"{name} ALARM!")
							print(Fore.WHITE, end='')
							subprocess.Popen([sys.executable, script])
							err_c = 0
					else:
						prev_ts = last_ts
						err_c = 0
						self.log._info(f"{name} OK")
				else:
					prev_ts = last_ts
					self.log._info(f"{name} OK")
				# print(f"{prev_ts}  |  {last_ts}")
			except Exception as err:
				self.log._debug(str(err))
		else:
			self.log._info(f"Monitoring data NOT Found! Start '{name}' first.")
		return prev_ts, err_c



async def run_tasks():
	while True:
		try:
			tasks = []
			t1 = Monitoring(
				logfile=MONITORING_LOG,
				script_name='monitor',
				debug=MONITORING_DEBUG,
				)	# Village 01 Check Attacks
			#t2 = Atergatis(village_name='01')	# Village 01 Check Adventures
			# tasks = [t1.atk_mon(ATK_MON), t1.adv_mon(ADV_MON), t1.farm_mon(FARM_MON)]

			if ADVENTURES_MON_ENABLED:
				tasks.append(t1.monitoring(ADVENTURES_MON))
			if ATTACKS_MON_ENABLED:
				tasks.append(t1.monitoring(ATTACKS_MON))
			if FARM_MON_ENABLED:
				tasks.append(t1.monitoring(FARM_MON))
			if OVERRES_MON_ENABLED:
				tasks.append(t1.monitoring(OVERRES_MON))
			if BANDAGES_MON_ENABLED:
				tasks.append(t1.monitoring(BANDAGES_MON))
			
			await asyncio.wait(tasks)
		except Exception as err:
			print(str(err))
			time.sleep(20)


def main():
	loop = asyncio.get_event_loop()
	loop.run_until_complete(run_tasks())
	loop.close()


if __name__ == '__main__':
	main()