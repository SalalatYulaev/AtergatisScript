import time
import re
import sys
from sys import argv
import os
import subprocess
import asyncio
from datetime import datetime
from colorama import Fore, Back, Style
from var import	*
from AtergatisMain import AtergatisOnline



class AtergatisAttacks(AtergatisOnline):
	def __init__(self, village_name, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisAttacks' initialized")
		self.mon_file = ATTACKS_MON['file']
		self.check_mon_file()
		self.village_name = village_name
		self.log.village_name = self.village_name
		self.village_link = self._get_village_link(self.village_name)
		self.log._debug("Village link retreived from '_get_village_link' function: " + self.village_link)



	async def infinit_check_attacks(self):
		self.log._debug("Started infinit_check_attacks function")
		await asyncio.sleep(0.5)
		arrival = ''		
		self.log._debug("Opening village link")
		self.driver.get(self.village_link)
		while True:
			try:
				self.log._debug("Updating monitoring file")
				self.log._debug("Opening attacks_on_me link")
				self.driver.get(ATTACKS_ON_ME_LINK)
				await asyncio.sleep(1)
				selector = "#build > span"
				self.log._debug("Checking attacks")
				result = self.driver.find_element_by_css_selector(selector).text
				if result == 'No incoming troops':
					self.log._info(f'{result}. Waiting {ATTACKS_SLEEP}')
					await asyncio.sleep(ATTACKS_SLEEP)

			except Exception as err:
				self.log._debug(f"Exception: {err}")
				self.log._debug("Retrieving attackers village name")
				src_village_name = self.driver.find_element_by_css_selector("#build > table > thead > tr > td.role > a").text
				self.log._debug(f"{src_village_name}")
				self.log._debug("Retrieving arrival")
				src_arrival = self.driver.find_element_by_css_selector("#build > table > tbody.infos > tr > td > div.at > span:nth-child(1)").text
				self.log._debug(f"{src_arrival}")
				regexp = r'Arrival at (\d+\:\d+\:\d+)'
				self.log._debug("Modifieng arrival")
				src_arrival = re.search(regexp, src_arrival).group(1)
				self.log._debug(f"{src_arrival}")
				self.log._debug("Retrieving time remain")
				time_remain = self.driver.find_element_by_css_selector("#timer1").text
				self.log._debug(f"{time_remain}")
				self.log._debug("Clicking attacers village button")
				pidor_village_button = self.driver.find_element_by_css_selector("#build > table > thead > tr > td.role > a").click()
				self.log._debug("Retrieving attackers Name")
				src_name = self.driver.find_element_by_css_selector("#village_info > tbody > tr:nth-child(3) > td > a").text
				self.log._debug(f"{src_name}")

				self.tbot("ATTACK", level='pzdc')
				if arrival != src_arrival:
					print(Back.RED, end='')
					#print(Fore.BLACK, end='')
					self.log._info('======= ATTACK ==========================')
					#self.log._info(f'Account:  {USERNAME}')
					self.log._info(f'Attacker: {src_name}')
					self.log._info(f'Village:  {src_village_name}')
					self.log._info(f'Arrival:  {src_arrival}')
					self.log._info(f'Remain:   {time_remain}')
					self.log._info('=========================================')
					print(Back.BLACK, end='')
					print(Fore.WHITE, end='')
					arrival = src_arrival
					self.tbot(f"Attacker: {src_name}\nVillage:  {src_village_name}\nArrival:  {src_arrival}\nRemain:   {time_remain}", level='pzdc')
					self.log._info('Executing Save Troops Script.')
					subprocess.Popen([sys.executable, SAVE_TROOPS_SCRIPT, self.village_name, time_remain, src_village_name, src_arrival, src_name])
					self.log._info(f'Sleeping {ATTACKS_SLEEP}')
					await asyncio.sleep(ATTACKS_SLEEP)
				else:
					self.log._info(f'TA ZHE ATAKA. Sleeping {ATTACKS_SLEEP}')
					await asyncio.sleep(ATTACKS_SLEEP)


async def run_tasks():
	while True:
		try:
			t1 = AtergatisAttacks(
				logfile=ATTACKS_LOG,
				village_name = argv[1],
				script_name='attacks',
				debug=ATTACKS_DEBUG,
			)
			# t1.log._debug("Something wrong. Restarting script..")
			# t1.logout()
			tasks = [t1.infinit_check_attacks(), t1.amalive()]
			await asyncio.wait(tasks)
		except Exception as err:
			print(Fore.RED, end='')
			print(str(err))
			print(Fore.WHITE, end='')
			t1.logout()
			time.sleep(10)
	

def main():
	loop = asyncio.get_event_loop()
	loop.run_until_complete(run_tasks())
	loop.close()


if __name__ == '__main__':
	main()