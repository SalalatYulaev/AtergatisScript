import time
#import random
#import yaml
import os
from colorama import Fore, Back, Style
from var import	*
from AtergatisMain import AtergatisOnline



class AtergatisDorf2(AtergatisOnline):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisDorf2' initialized")
		self.data = self.get_data()['build_dorf2']
		for villa, buildings in self.data.items():
			self.village_name = villa
			self.buildings = buildings
		self.village_link = self._get_village_link(self.village_name)
		self.log.village_name = self.village_name
		self.log._debug("Village link retreived from '_get_village_link' function: " + self.village_link)


	def upgrade_dorf2(self):
		self.log._debug(f"Buildings: {self.buildings}")
		
		for building in self.buildings:		
			field_num = building['field_numb']
			target_level = int(building['target_lvl'])
			while True:
				self.driver.get(self.village_link)
				q_status = self._check_building_queue()			
				if q_status != 'd2_busy' and q_status != 'all_busy':
					link = FIELD_LINK + field_num
					try:
						wait = self.upgrade_field(link, target_level=target_level)		
						if wait == 315548:
							self.log._debug(f"Field num {field_num} is MAX lvl")
							break
						else:
							self.log._debug(f'Waiting {wait} seconds.')
							time.sleep(wait)
					except Exception as err:
						self.log._debug(f'Last level reached on field number {field_num}')
						time.sleep(5)
						break
				else:
					self.log._debug('Sleeping 60')
					time.sleep(10)
		return 315548



def main():
	while True:
		try:
			task = AtergatisDorf2(
				logfile=UPGRADE_LOG,
				script_name='dorf2',
				debug=BUILD_DEBUG,
			)
			if task.upgrade_dorf2() == 315548:
				task.log._info('All buildings are upgraded.')
				msg = f"{USERNAME}\nVilla: {task.village_name}\n{task.script_name}\nAll buildings are upgraded.".replace('_', '-')
				task.tbot(msg)				
				task.logout()
				break
			task.log._debug("Something wrong. Restarting script..")

		except Exception as err:
			print(str(err))
			time.sleep(10)

if __name__ == '__main__':
	main()

