import time
#import random
#import yaml
import os
from colorama import init
from colorama import Fore, Back, Style

from var import	*
from AtergatisMain import (
	 Atergatis, 
	 AtergatisOnline, 
	 AtergatisLogger
)



# Colorama
init()



class AtergatisDorf2(AtergatisOnline):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisDorf2' initialized")
		self.village_name, self.village_link, self.target_level = self._get_dorf1_queue()
		self.log.village_name = self.village_name
		self.log._debug("Village link retreived from '_get_village_link' function: " + self.village_link)


	def upgrade_dorf2(self):
		self.village_name, self.village_link, buildings = self._get_dorf2_queue()
		self.log._debug("Buildings:     {}".format(str(buildings)))
		
		for building in buildings:		
			field_num = building['field_num']
			target_level = int(building['target_level'])
			while True:
				self.driver.get(self.village_link)
				q_status = self._check_building_queue()			
				if q_status != 'd2_busy' and q_status != 'all_busy':
					link = FIELD_LINK + field_num
					try:
						wait = self.upgrade_field(link, target_level=self.target_level)		
						if wait == 315548:
							self.log._debug(f"Field num {field_num} is MAX lvl")
							break
						else:
							self.log._debug(f'Waiting {wait} seconds.')
							time.sleep(wait)
					except Exception as err:
						self.log._debug(f'Last level reached on field number {field_num}')
						time.sleep(5)
						break
				else:
					self.log._debug('Sleeping 60')
					time.sleep(10)
		return 315548



def main():
	while True:
		try:
			task = AtergatisDorf2(
				logfile=UPGRADE_LOG,
				script_name='dorf2',
				debug=BUILD_DEBUG,
			)
			if task.upgrade_dorf2() == 315548:
				task.log._info('All buildings are upgraded.')
				msg = f"{USERNAME}\nVilla: {task.village_name}\n{task.script_name}\nAll buildings are upgraded.".replace('_', '-')
				task.tbot(msg)				
				task.logout()
				break
			task.log._debug("Something wrong. Restarting script..")

		except Exception as err:
			print(str(err))
			time.sleep(10)

if __name__ == '__main__':
	main()

