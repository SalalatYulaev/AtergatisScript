import time 
import subprocess
import sys
import asyncio
import random
import requests
import re
import os
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from datetime import datetime
from var import	*
from colorama import init
from colorama import Fore, Back, Style



# Colorama
init()


class Atergatis:
	def __init__(self, **kwargs):
		self.log = AtergatisLogger(**kwargs)
		self.log._debug("Class Atergatis initialized")
		self.log._debug(f"Parameters: {kwargs}")
		if USERCONFIG_DEBUG:
			self.log._debug("Reading user config file")
			for key, value in CONFIG_DATA.items():
				if key != 'password':
					self.log._debug(f"{key}: {value}")
		self.account = USERNAME
		if self.__check_permission():
			if 'script_name' in kwargs:
				self.script_name = kwargs['script_name']
			if 'village_name' in kwargs:
				self.village_name = kwargs['village_name']
			if 'village_link' in kwargs:
				self.village_link = kwargs['village_link']



	def get_data(self):
		with open(ACTIONS_FILE) as f:
			return yaml.safe_load(f)


	@staticmethod
	def _get_sec(time_string):
		time = time_string.split(':')
		ttw = int(time[0]) * 3600 + int(time[1]) * 60 + int(time[2])	
		return ttw


	def _get_village_link(self, village_name):
		self.log._debug("Started _get_village_link function")
		self.log._debug(f"Village name: {village_name}")
		village_link = ''
		for villa in VILLAGES:
			for villa_name, link in villa.items():
				if village_name in villa_name:
					village_link = link
					return village_link



	@staticmethod
	def tbot(message, level='normal'):
		if level == 'normal':
			bot_token = '1289159109:AAHspKIt6Yhu-WkbmV8fcVDcu17ibtE0k-Q'
			bot_chatID = '-1001435139327'
			send_text = 'https://api.telegram.org/bot' + bot_token + '/sendMessage?chat_id=' + bot_chatID + '&parse_mode=Markdown&text=' + message
			response = requests.get(send_text)
			return response.json()
		else:
			bot_token = '980755404:AAFwlTcBHs-p1jZti3ZXffNfen1EArlQmjY'
			bot_chatID = '-320637181'
			send_text = 'https://api.telegram.org/bot' + bot_token + '/sendMessage?chat_id=' + bot_chatID + '&parse_mode=Markdown&text=' + message
			response = requests.get(send_text)
			return response.json()


	def __check_permission(self):
		response = requests.get('https://raw.githubusercontent.com/SalalatYulaev/AtergatisUsers/master/usercontracts.yaml').text
		cur_timestamp = datetime.now()
		data = yaml.safe_load(response)
		if USERNAME in data.keys():
			for user, expiration in data.items():
				self.log._debug(f"Current date: {cur_timestamp}. Expiration date: {expiration}")
				if user == USERNAME:
					if expiration.year > cur_timestamp.year:
						self.log._debug("Permission granted.")
						return True
					elif expiration.year == cur_timestamp.year:
						if expiration.month > cur_timestamp.month:
							self.log._debug("Permission granted.")
							return True
						elif expiration.month == cur_timestamp.month:
							if expiration.day >= cur_timestamp.day:
								self.log._debug("Permission granted.")
								return True
							elif expiration.day < cur_timestamp.day:
								self.log._info("Permission of using Atergatis Scripts has expired!")
								return False
						else:
							self.log._info("Permission of using Atergatis Scripts has expired!")
							return False
					else:
						self.log._info("Permission of using Atergatis Scripts has expired!")
						return False
		else:
			print(Fore.RED, end='')
			self.log._info(f"User {USERNAME} not permitted to use Atergatis Scripts!")
			print(Fore.WHITE, end='')
			return False



class AtergatisOnline(Atergatis):
	def __init__(self, **kwargs):		
		super().__init__(**kwargs)
		self.log._debug("Class AtergatisOnline initialized")
		self.driver = webdriver.Chrome("C:\\chromedriver\\chromedriver.exe")
		self.driver.get(SERVER_LINK)
		user_prompt = self.driver.find_element_by_name("user")
		user_prompt.send_keys(USERNAME)
		pass_prompt = self.driver.find_element_by_name("pw")
		pass_prompt.send_keys(PASSWORD)
		login_button = self.driver.find_element_by_css_selector("div.button-content")
		login_button.click()
		time.sleep(1)


	def check_mon_file(self):
			self.log._debug("Started check_mon_file function")
			if os.path.exists(self.mon_file):
				self.log._debug("Monitoring file exists. Removing...")
				os.remove(self.mon_file)
				self.log._debug("OK")
			else:
				self.log._debug("Monitoring file NOT exists.")


	async def amalive(self):
		while True:
			with open(self.mon_file, "a") as f:
				ts = datetime.strftime(datetime.now(), "%H%M%S")
				f.write(f"{ts}\n")
				self.log._debug(f"Keep alive timestamp: {ts}")
			await asyncio.sleep(MONITORING_SLEEP)
			

	def _check_hero_status(self):
		self.log._debug("Started _check_hero_status function")
		status = self.driver.find_element_by_css_selector("#sidebarBoxHero > div.sidebarBoxInnerBox > div.innerBox.content > div.heroStatusMessage").text
		return status


	def _check_building_queue(self):
		self.log._debug("Started _check_building_queue function")
		res = ['Woodcutter', 'Clay', 'Iron', 'Cropland']
		is_building = False

		try:
			self.driver.refresh()
			queue = self.driver.find_element_by_css_selector("#content > div.boxes.buildingList > div.boxes-contents.cf > ul").text
			q_len = [i for i in queue.split('\n')]

			if len(q_len) == 6:
				self.log._debug('Three buildings in queue')
				self.log._info('All building slots are busy.')
				return 'all_busy'
			if len(q_len) == 4:
				self.log._debug('Two buildings in queue')
				res_queue = []
				for line in queue.split('\n'):
					for one in res:
						if one in line:
							res_queue.append(one)
				if len(res_queue) == 2:
					self.log._info('Resource field is currently building.')
					return 'd1_busy'
				if len(res_queue) == 1:
					self.log._info('All building slots are busy.')
					return 'all_busy'
				else:
					self.log._debug('Dorf 2 field is currently building.')
					return 'd2_busy'
			if len(q_len) == 2:
				self.log._debug('One building in queue')
				for line in queue.split('\n'):
					for one in res:
						if one in line:
							is_building = True
					if is_building:
						self.log._info('Resource field is currently building.')
						return 'd1_busy'
					else:
						self.log._info('Dorf 2 field is currently building.')
						return 'd2_busy'					
		except Exception as err:
			# self.log._info('CHECK Queue ' + str(err))  # For debug
			self.log._debug('Building queue is free.')
			return 'clear'


	def _check_resources(self):
		self.log._debug("Checking resourses amount")
		ress = ['#l1', '#l2', '#l3', '#l4']
		resources = []
		for res in ress:
			amount = self.driver.find_element_by_css_selector(res).text
			resources.append(int(amount.replace(',', '')))
		self.log._debug(resources)
		wood, clay, iron, crop = resources
		return resources


	def _need_resources(self):
		self.log._debug("Checking needed resourses")
		ress = ['r1', 'r2', 'r3', 'r4']
		resources = []
		for res in ress:
			selector = '#contract > div.contractCosts > div > span.resources.' + res
			amount = self.driver.find_element_by_css_selector(selector).text
			resources.append(int(amount))
		self.log._debug(resources)
		return resources


	def wh_cap(self):
		self.log._debug("Calculating WH capacity")
		wh_capacity = self.driver.find_element_by_css_selector("#stockBarWarehouse").text.replace(',', '')
		self.log._debug(f"WH capacity {wh_capacity}")
		return wh_capacity


	def gr_cap(self):
		self.log._debug("Calculating GR capacity")
		gr_capacity = self.driver.find_element_by_css_selector("#stockBarGranary").text.replace(',', '')
		self.log._debug(f"GR capacity {gr_capacity}")
		return gr_capacity


	def is_wh_full(self, main_resources):
		self.log._debug("Started is_wh_full function")
		capacity = self.wh_cap()
		for res in main_resources:
			if str(res) == capacity:
				self.log._debug(f"{res} is full")
				return True
		self.log._debug("Warehouse is NOT full")
		return False


	def is_gr_full(self, crop_amount):
		self.log._debug("Started is_gr_full function")
		capacity = self.gr_cap()
		if str(crop_amount) == capacity:
			self.log._debug("Granary is full")
			return True
		else:
			self.log._debug("Granary is NOT full")
			return False


	def upgrade_field(self, link, target_level=10):
		self.log._debug("Started upgrade_field function")
		regexp = r'(.*) Level'
		self.log._debug("Opening village link")
		self.driver.get(link)
		self.log._debug("Parsing cur_level")
		cur_level = int(self.driver.find_element_by_css_selector("#content > h1 > span").text.split()[-1])
		self.log._debug(f"cur_level: {cur_level}")
		next_level = cur_level + 1
		self.log._debug("Parsing field name")
		_building = self.driver.find_element_by_css_selector("#content > h1").text
		building = re.search(regexp, _building).group(1)
		self.log._debug(f"Field name: {building}")
		print(Fore.GREEN, end='')
		self.log._info(f'Upgrading {building}. Current {cur_level}. Target {target_level}.')
		print(Fore.WHITE, end='')
		if int(cur_level) >= int(target_level):
			self.log._info(f'Level {target_level} already reached.')
			return 315548
		else:
			self.log._debug('Target level not reached')
			cur_wood, cur_clay, cur_iron, cur_crop = self._check_resources()
			need_wood, need_clay, need_iron, need_crop = self._need_resources()
			self.log._debug("Calculating wait")
			wait = self.driver.find_element_by_css_selector("#contract > div.contractCosts > div > span.clocks").text
			self.log._debug("Translating wait text into sec")
			ttw = self._get_sec(wait)
			self.log._debug(f"Time to wait: {ttw}")
			if need_wood <= cur_wood and need_clay <= cur_clay and need_iron <= cur_iron and need_crop <= cur_crop:
				self.log._debug("Clicking upgrade button")
				#contract > button > div > div.button-content
				self.driver.find_element_by_css_selector("#contract > button > div > div.button-content").click()
				self.log._debug(f"Returning ttw: {ttw}")
				return ttw
			else:
				self.log._info(f'Not Enough resources. Sleeping {BUILDING_SLEEP}.')
				return BUILDING_SLEEP


	def redistr_res(self):
		self.log._debug("Opening market link")
		self.driver.get("http://tx" + SPEED + ".atergatis.com/build.php?gid=17&t=1")
		time.sleep(1)
		self.log._debug("Clicking redistribute button")
		self.driver.find_element_by_css_selector("button.gold").click()
		time.sleep(1)
		self.log._debug("Clicking redistribute button #2")
		self.driver.find_element_by_css_selector("[onclick='javascript:Atergatis.Game.Marketplace.ExchangeResources.portionOut();']").click()
		time.sleep(1)
		for i in range(3):
			self.log._debug(f"sending 0 key {i} time")
			self.driver.find_element_by_id("m2[3]").clear()
			self.driver.find_element_by_id("m2[3]").send_keys("0")
			self.log._debug(f"Clicking exchange button {i} time")
			self.driver.find_element_by_css_selector("[onclick='javascript:Atergatis.Game.Marketplace.ExchangeResources.portionOut();']").click()
			time.sleep(1)
		self.log._debug("Clicking npc_market_button")
		self.driver.find_element_by_id("npc_market_button").click()


	def train_all_big_caesaris(self):
		self.log._debug("Opening stable")
		self.driver.get(FIELD_LINK + '25')
		self.log._debug("Selecting all caesaris horses")
		self.driver.find_element_by_css_selector("#build > form > div.buildActionOverview.trainUnits > div.action.first > div.details > a").click()
		self.log._debug(f"Clicking train button")
		self.driver.find_element_by_css_selector("#btn_train > div > div.button-content").click()


	def logout(self):
		self.driver.quit()



class AtergatisLogger():
	def __init__(self,
		logfile,
		script_name = '',
		village_name = '',
		# village_link = '',
		debug = False,
		terminal_debug = False):
		self.logfile = logfile
		self.account = USERNAME		
		self.script_name = script_name
		self.village_name = village_name
		# self.village_link = village_link
		self.debug_flag = debug
		self.terminal_debug = terminal_debug


	@staticmethod
	def _log_msg(logfile, flag, data, _print=False):
		timestamp = datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")
		with open(logfile, 'a') as f:
			f.write("{:22}{:8}{}\n".format(timestamp, flag, data))
		if _print:
			print("{:22}{:8}{}".format(timestamp, flag, data))


	def _info(self, data):
		timestamp = datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")
		flag = "INFO"
		self.__log_write(timestamp, flag, data)
		self.__log_print(timestamp, flag, data)


	def _debug(self, data):
		if self.debug_flag:
			timestamp = datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")
			flag = "DEBUG"
			if self.terminal_debug:
				self.__log_print(timestamp, flag, data)
				self.__log_write(timestamp, flag, data)
			else:
				self.__log_write(timestamp, flag, data)


	def __log_write(self, timestamp, flag, data):
		with open(self.logfile, 'a') as f:
			f.write("{:22}{:8}{:15}{:5}{:10}{}\n".format(timestamp, flag, self.account, self.village_name, self.script_name, str(data)))


	def __log_print(self, timestamp, flag, data):
		print("{:22}{:8}{:15}{:5}{:10}{}".format(timestamp, flag, self.account, self.village_name, self.script_name, str(data)))



class AtergatisError(Exception):
	pass
