import time
import re
import yaml
from colorama import Fore, Back, Style
from var import	*
from AtergatisMain import AtergatisOnline



class AtergatisFarm(AtergatisOnline):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisFarm' initialized")
		self.data = self._get_farm_lists()
		# self.log.village_name = self.village_name
		# self.village_link = self._get_village_link(self.village_name)
		# self.log._debug("Village link retreived from '_get_village_link' function: " + self.village_link)
		self.infinit_send_farm()
		

	def _get_farm_lists(self):
		self.log._debug("Started 'get_farm_lists' function")
		with open(FARMLIST_FILE) as f:
			data = yaml.safe_load(f)
		self.log._debug("Data retreived from file: " + str(data))
		return data


	def infinit_send_farm(self):
		self.log._debug("Started 'infinit_send_farm' function")
		while True:
			for entry in self.data:
				for villa, flists in entry.items():
					# open villa link
					self.village_name = villa
					self.log.village_name = villa
					self.village_link = self._get_village_link(self.village_name)
					self.log._debug("Opening village link")
					self.driver.get(self.village_link)
					self.log._debug("Opening farm_list link")
					self.driver.get(FARM_LIST_LINK)
					self.log._debug("Sleeping 3 sec")
					time.sleep(3)
					self.log._debug("Check if any troops died")
					try:
						self.driver.find_element_by_css_selector("img.iReport.iReport17")
						self.log._info("Farm troops died! Check farm-lists!")
						self.tbot(f'{USERNAME}\nFarm troops died! Check farm-lists!'.replace('_', '-'))
					except Exception as err:
						self.log._debug("None troop died. Processing..")					
					for flist in flists:
						self.log._debug(f"Starting sending farm from village {self.village_name}")
						self.send_farm(**flist)
			self.log._info(f" All Farm sent. Sleeping {FARM_SLEEP}" )
			time.sleep(FARM_SLEEP)


	def send_farm(self, list_id, list_name):
		self.log._debug(f"Started 'send_farm' function. List ID: {list_id}, list_name: {list_name}")
		list_link = "#raidListMarkAll" + list_id
		self.log._debug("List link selector: " + list_link)
		send_button = "#list" + list_id + " > form > div.listContent > button > div > div.button-content"
		self.log._debug("Send button selector: " + send_button)
		self.driver.find_element_by_css_selector(list_link).click()
		self.log._debug("Checkbox checked")
		time.sleep(1)
		self.driver.find_element_by_css_selector(send_button).click()
		self.log._debug("'Send' button pressed. Sleeping 3 sec" )
		time.sleep(3)
			


def main():
	while True:
		try:
			task = AtergatisFarm(
				logfile=FARM_LOG,
				script_name='farm',
				debug=FARM_DEBUG,
			)
			task.log._debug("Something wrong. Restarting script..")
			task.logout()
		except Exception as err:
			print(str(err))
			time.sleep(10)
			

if __name__ == '__main__':
	main()


