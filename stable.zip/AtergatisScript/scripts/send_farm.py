import time
import re
import os
import yaml
import asyncio
from colorama import Fore, Back, Style
from var import	*
from AtergatisMain import AtergatisOnline
from datetime import datetime



class AtergatisFarm(AtergatisOnline):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisFarm' initialized")
		self.mon_file = FARM_MON['file']
		self.check_mon_file()
		# self.data = self._get_farm_lists()
		# self._get_farm_lists()
		self.data = self.get_data()['farm_lists']
		

	# def _get_farm_lists(self):
	# 	self.log._debug("Started 'get_farm_lists' function")
	# 	with open(FARMLIST_FILE) as f:
	# 		self.data = yaml.safe_load(f)
	# 	self.log._debug("Data retreived from file: " + str(data))
		# return data


	async def infinit_send_farm(self):
		self.log._debug("Started 'infinit_send_farm' function")
		await asyncio.sleep(0.5)
		while True:
			for villa, flists in self.data.items():
				# open villa link
				self.village_name = villa
				self.log.village_name = villa
				self.village_link = self._get_village_link(self.village_name)
				self.log._debug("Opening village link")
				self.driver.get(self.village_link)
				self.log._debug("Opening farm_list link")
				self.driver.get(FARM_LIST_LINK)
				self.log._debug("Sleeping 3 sec")
				await asyncio.sleep(3)
				self.log._debug("Check if any troops died")
				try:
					self.driver.find_element_by_css_selector("img.iReport.iReport17")
					self.log._info("Farm troops died! Check farm-lists!")
					self.tbot(f'{USERNAME}\nFarm troops died! Check farm-lists!'.replace('_', '-'))
				except Exception as err:
					self.log._debug("None troop died. Processing..")					
				for flist in flists:
					self.log._debug(f"Starting sending farm from village {self.village_name}")
					self.send_farm(**flist)
			self.log._info(f" All Farm sent. Sleeping {FARM_SLEEP}" )
			await asyncio.sleep(FARM_SLEEP)


	def send_farm(self, list_id, list_name):
		self.log._debug(f"Started 'send_farm' function. List ID: {list_id}, list_name: {list_name}")
		list_link = "#raidListMarkAll" + list_id
		self.log._debug("List link selector: " + list_link)
		send_button = "#list" + list_id + " > form > div.listContent > button > div > div.button-content"
		self.log._debug("Send button selector: " + send_button)
		self.driver.find_element_by_css_selector(list_link).click()
		self.log._debug("Checkbox checked")
		time.sleep(1)
		self.driver.find_element_by_css_selector(send_button).click()
		self.log._debug("'Send' button pressed. Sleeping 3 sec" )
		time.sleep(3)


async def run_tasks():
	while True:
		try:
			t1 = AtergatisFarm(
				logfile=FARM_LOG,
				script_name='farm',
				debug=FARM_DEBUG,
			)
			# task.log._debug("Something wrong. Restarting script..")
			# task.logout()
			tasks = [t1.infinit_send_farm(), t1.amalive()]
			await asyncio.wait(tasks)
		except Exception as err:
			print(Fore.RED, end='')
			print(str(err))
			print(Fore.WHITE, end='')
			time.sleep(10)
	

def main():
	loop = asyncio.get_event_loop()
	loop.run_until_complete(run_tasks())
	loop.close()


if __name__ == '__main__':
	main()
