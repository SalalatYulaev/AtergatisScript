import yaml


with open('config.yaml') as f:
	data = yaml.safe_load(f)

CONFIG_DATA = data

USERNAME = data['username']
PASSWORD = data['password']
SPEED = str(data['speed'])
HIDE_TROOPS_LINK = data['hide_troops_link']

VILLAGE_ID 	= "http://tx" + SPEED + ".atergatis.com/dorf1.php?newdid="

VILLAGES_ = data['villages']
VILLAGES = []
for name, id_ in VILLAGES_.items():
	villa = {}
	villa_link = VILLAGE_ID + id_
	villa[name] = villa_link
	VILLAGES.append(villa)
	
HERO_VILLAGE = data['hero_village']
HERO_MAP_PERSENT = str(data['hero_map_persent'])

TARGET_BANDAGES = data['target_bandages']
BANDAGES_MIN_BID = data['bandages_min_bid']
BANDAGES_MAX_BID = data['bandages_max_bid']

ATTACKS_MON_ENABLED = data['attacks_mon']
ADVENTURES_MON_ENABLED = data['adventures_mon']
FARM_MON_ENABLED = data['farm_mon']
OVERRES_MON_ENABLED = data['overres_mon']
BANDAGES_MON_ENABLED = data['bandages_mon']


#############################################################################################
###	SLEEPS
#############################################################################################
ATTACKS_SLEEP = data['attacks_sleep']
BUILDING_SLEEP = data['building_sleep']
FARM_SLEEP = data['farm_sleep']
ADVENTURES_SLEEP = data['adventures_sleep']
OVERRES_SLEEP = data['overres_sleep']
BANDAGES_SLEEP = data['bandages_sleep']
MONITORING_SLEEP = data['monitoring_sleep']


#############################################################################################
###	DEBUG
#############################################################################################
USERCONFIG_DEBUG = data['userconfig_debug']
ATTACKS_DEBUG = data['attacks_debug']
FARM_DEBUG = data['farm_debug']
ADVENTURES_DEBUG = data['adventures_debug']
BUILD_DEBUG = data['build_debug']
ELEPHANTS_DEBUG = data['elephants_debug']
OVERRES_DEBUG = data['overres_debug']
RASKAT_DEBUG = data['raskat_debug']
BANDAGES_DEBUG = data['bandages_debug']
MONITORING_DEBUG = data['monitoring_debug']


#############################################################################################
###	SCRIPTS
#############################################################################################
SCRIPTS_PATH = "scripts\\"

D1_UPGRADE_SCRIPT	= SCRIPTS_PATH + "dorf1_upgrade.py"
D2_UPGRADE_SCRIPT	= SCRIPTS_PATH + "dorf2_upgrade.py"
ADVENTURES_SCRIPT 	= SCRIPTS_PATH + "check_adventures.py"
MAIN_SCRIPT			= SCRIPTS_PATH + "AtergatisMain.py"
RASKAT_SCRIPT		= SCRIPTS_PATH + "raskat.py"
FARM_SCRIPT 		= SCRIPTS_PATH + "send_farm.py"
OVERRES_SCRIPT		= SCRIPTS_PATH + "check_overres.py"
ATTACKS_SCRIPT		= SCRIPTS_PATH + "check_attacks.py"
ATTACKS_HANDLER		= SCRIPTS_PATH + "check_attacks_handler.py"
ELEPHANTS_SCRIPT	= SCRIPTS_PATH + "elephants_finder.py"
SAVE_TROOPS_SCRIPT	= SCRIPTS_PATH + "save_troops.py"
BANDAGES_SCRIPT		= SCRIPTS_PATH + "buy_bandages.py"
MAIN_TASKS_SCRIPT	= SCRIPTS_PATH + "main_tasks.py"
MONITORING_SCRIPT	= SCRIPTS_PATH + "monitoring.py"


#############################################################################################
### EXECUTORS
#############################################################################################
e1 =  {'executor_Dorf1.bat': D1_UPGRADE_SCRIPT}
e2 =  {'executor_Dorf2.bat': D2_UPGRADE_SCRIPT}
e3 =  {'executor_Adventures.bat': ADVENTURES_SCRIPT}
# e4 =  {'executor_Main.bat': MAIN_SCRIPT}
e5 =  {'executor_Raskat.bat': RASKAT_SCRIPT}
e6 =  {'executor_Send_Farm.bat': FARM_SCRIPT}
e7 =  {'executor_Check_Overres.bat': OVERRES_SCRIPT}
e8 =  {'executor_Check_Attacks.bat': ATTACKS_SCRIPT}
e9 =  {'executor_Elephants.bat': ELEPHANTS_SCRIPT}
e10 = {'executor_Bandages.bat': BANDAGES_SCRIPT}
e11 = {'executor_Main_Tasks.bat': MAIN_TASKS_SCRIPT}
e12 = {'executor_Monitoring.bat': MONITORING_SCRIPT}

EXECUTORS = [e1, e2, e3, e5, e6, e7, e8, e9, e10, e11, e12]


#############################################################################################
###	LINKS
#############################################################################################
SERVER_LINK = "http://tx" + SPEED + ".atergatis.com/"

DORF1_LINK 	= "http://tx" + SPEED + ".atergatis.com/dorf1.php"
DORF2_LINK 	= "http://tx" + SPEED + ".atergatis.com/dorf2.php"
MAIL_LINK 	= "http://tx" + SPEED + ".atergatis.com/nachrichten.php"
REPORT_LINK = "http://tx" + SPEED + ".atergatis.com/berichte.php"
FIELD_LINK 	= "http://tx" + SPEED + ".atergatis.com/build.php?id="
COORDS_LINK = "http://tx" + SPEED + ".atergatis.com/position_details.php?"
ATTACKS_ON_ME_LINK 	= "http://tx" + SPEED + ".atergatis.com/build.php?gid=16&filter=1&subfilters=1&t=2"
FARM_LIST_LINK 		= "http://tx" + SPEED + ".atergatis.com/build.php?id=39&t=5"
SEND_TROOPS_LINK 	= "http://tx" + SPEED + ".atergatis.com/a2b.php?z="

#############################################################################################
###	FILES
#############################################################################################
TASKS_FILE 		 = "data_tasks.yaml"
ACTIONS_FILE     = "actions.yaml"
DORF1_DATA_FILE  = "data_build_dorf1.yaml"
DORF2_DATA_FILE  = "data_build_dorf2.yaml"
RASKAT_DATA_FILE = "data_raskat.yaml"
FARMLIST_FILE	 = "data_farmlist.yaml"


#############################################################################################
### ATTACKS AND HIDE TROOPS
#############################################################################################
tr1 = "a[onclick*='document.snd.t1']"
tr2 = "[onclick*='document.snd.t2']"
tr3 = "[onclick*='document.snd.t3']"
tr4 = "[onclick*='document.snd.t4']"
tr5 = "[onclick*='document.snd.t5']"
tr6 = "[onclick*='document.snd.t6']"
tr7 = "[onclick*='document.snd.t7']"
tr8 = "[onclick*='document.snd.t8']"
tr9 = "[onclick*='document.snd.t9']"
tr10 = "[onclick*='document.snd.t10']"
tr11 = "a[onclick*='document.snd.t11']"


#############################################################################################
### LOGS
#############################################################################################
LOGS_PATH = "logs\\"

ATTACKS_LOG 	= LOGS_PATH + "attacks.log"
FARM_LOG 		= LOGS_PATH + "farm.log"
ADVENTURES_LOG 	= LOGS_PATH + "adventures.log"
OVERRES_LOG 	= LOGS_PATH + "overres.log"
UPGRADE_LOG 	= LOGS_PATH + "upgrade.log"
SAVE_TROOS_LOG 	= LOGS_PATH + "save_troops.log"
MAIN_LOG 		= LOGS_PATH + "main.log"
TRAIN_LOG		= LOGS_PATH + "train_troops.log"
TEST_LOG 		= LOGS_PATH + "test.log"
RASKAT_LOG		= LOGS_PATH + "raskat.log"
INIT_LOG		= LOGS_PATH + "init.log"
ELEPHANTS_LOG   = LOGS_PATH + "elephants.log"
BANDAGES_LOG	= LOGS_PATH + "bandages.log"
MONITORING_LOG  = LOGS_PATH + "monitoring.log"


#############################################################################################
### MONITORING
#############################################################################################
MON_DIR = "monitoring\\"

ADVENTURES_MON 	= {'file': MON_DIR + "adventures.mon", 'name': 'check_adventures', 'script': ADVENTURES_SCRIPT}
ATTACKS_MON 	= {'file': MON_DIR + "attacks.mon", 'name': 'check_attacks', 'script': ATTACKS_SCRIPT}
FARM_MON 		= {'file': MON_DIR + "farm.mon", 'name': 'send_farm', 'script': FARM_SCRIPT}
OVERRES_MON		= {'file': MON_DIR + "overres.mon", 'name': 'overres', 'script': OVERRES_SCRIPT}
BANDAGES_MON 	= {'file': MON_DIR + "bandages.mon", 'name': 'bandages', 'script': BANDAGES_SCRIPT}