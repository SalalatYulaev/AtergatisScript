from sys import argv
import time
import random
from var import	*
from AtergatisMain import (Atergatis, AtergatisOnline)


# subprocess.Popen([sys.executable, SAVE_TROOPS_SCRIPT, self.village_name, time_remain, pidor_village_name, pidor_arrival, pidor_name])


logfile = ATTACKS_LOG


village_name = argv[1]
time_remain = argv[2]
src_village_name = argv[4]
arrival = argv[4]
attacker = argv[5]


rand = random.randrange(1,7)
remain = time_remain
time_remain = Atergatis._get_sec(time_remain)
tts = time_remain - 120 - rand



class AtergatisHideTroops(AtergatisOnline):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.village_name = village_name
		self.log.village_name = self.village_name
		self.village_link = self._get_village_link(self.village_name)
		self.remain = time_remain
		self.src_village_name = src_village_name
		self.arrival = arrival
		self.attacker = attacker
		self.tts = tts
		self.hide_troops()


	def hide_troops(self):
		if time_remain >= 60:
			self.log._info(f"Sleeping {time_remain-1} before attack")
			time.sleep(time_remain - 60)
		else:
			self.log._info("Fast attack!!")
		self.log._info("starting hiding troops")			
		troops = [tr1, tr2, tr3, tr4, tr5, tr6, tr7, tr8, tr9, tr10, tr11]
		self.driver.get(self.village_link)
		#time.sleep(1)
		self.driver.get(HIDE_TROOPS_LINK)
		for tf in troops: 
			try:
				select_troops = self.driver.find_element_by_css_selector(tf).click()
				time.sleep(0.5)
			except Exception as err:
				time.sleep(0.5)
				continue
		self.log._info('All troops selected')
		reinforcement_button 	= self.driver.find_element_by_css_selector("#build > form > div.option > label:nth-child(1) > input").click()
		confirm_button 			= self.driver.find_element_by_css_selector("#btn_ok > div > div.button-content").click()
		confirm_button 			= self.driver.find_element_by_css_selector("#btn_ok > div > div.button-content").click()	
		self.log._info('Troops are safe.')
		time.sleep(5)
		self.logout()

if __name__ == '__main__':
	task = AtergatisHideTroops(	logfile=ATTACKS_LOG,
				script_name='attacks',
				debug=ATTACKS_DEBUG,
			)
	
