import time
import re
import sys
import os
import asyncio
from datetime import datetime
from colorama import Fore, Back, Style
from var import	*
from AtergatisMain import AtergatisOnline



class AtergatisAdventures(AtergatisOnline):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisAdventures' initialized")
		self.mon_file = ADVENTURES_MON['file']
		self.check_mon_file()	
		self.log._debug(f"Hero village: {HERO_VILLAGE}")
		self.village_link = self._get_village_link(self.village_name)
		self.log._debug("Village link retreived from '_get_village_link' function: " + self.village_link)


	async def adventure_check(self):		
		self.log._debug("Started 'adventure_check' function")
		await asyncio.sleep(0.5)
		while True:
			try:
				if self.check_conditions():
					wait = self.send_hero()
					await asyncio.sleep(wait)
				else:
					self.log._debug(f"Sleeping {ADVENTURES_SLEEP}")
					await asyncio.sleep(ADVENTURES_SLEEP)
			except Exception as err:
				self.log._debug("Exception: " + str(err))


	def check_conditions(self):
		self.log._debug("Started 'check_conditions' function")
		self.set_home_position()
		try:
			self.log._debug("Checking adventures amount")
			adv_amount = self.driver.find_element_by_css_selector("#button5325658731ba2 > div.speechBubbleContainer > div.speechBubbleContent").text
			self.log._info(f"Active adventures: {adv_amount}")
			status = self._check_hero_status()
			self.log._debug(f'Hero status: {status}')
			if status != 'on the way' and status != 'stands as reinforcement':
				self.log._debug("Conditions are OK")
				return True
			else:
				self.log._info(f'Hero not at home. Conditions are False')
				return False
		except Exception as err:
			self.log._debug("Exception: " + str(err))
			self.log._info(f"Adventures not found. Sleeping {ADVENTURES_SLEEP}")
			self.log._debug("-" * 50)


	def set_home_position(self):
		self.log._debug("Started 'set_home_position' function")
		self.log._debug("Opening village link")
		self.driver.get(self.village_link)
		self.log._debug("Opening dorf 2 link")		
		self.driver.get(DORF2_LINK)


	def send_hero(self):
		self.log._debug("Started 'send_hero' function")
		self.log._debug("Pressing Adventures button")
		adv_button = self.driver.find_element_by_css_selector("#button5325658731ba2 > div.button-container.addHoverClick").click()		
		time.sleep(1)
		self.log._debug("Retrieving time to adventure string")
		ttc = self.driver.find_element_by_css_selector("#content > table > tbody > tr:nth-child(1) > td.moveTime").text
		self.log._debug(f"Time to adventure: {ttc}")
		self.log._debug("Converting time to adventure into sec")
		to_adv = self._get_sec(ttc)
		self.log._debug(f"Time to adventure: {to_adv}")
		wait = self.calculate_wait(to_adv)
		self.log._debug("Clicking To the Adventure button")
		self.driver.find_element_by_css_selector("#content > table > tbody > tr:nth-child(1) > td.goTo > a").click()
		time.sleep(1)
		self.log._debug("Clicking 'Start Adventure' button")
		self.driver.find_element_by_css_selector("#start > div > div.button-content").click()
		time.sleep(1)
		self.log._debug("Opening dorf 2 link")
		self.driver.get(DORF2_LINK)		
		print(Fore.GREEN, end='')
		self.log._info(f"Hero sent to adventure. Sleeping {str(wait)} seconds")
		print(Fore.WHITE, end='')
		self.log._info("-" * 50)
		return wait


	def calculate_wait(self, to_adv):
		self.log._debug("Started 'calculate_wait' function")
		self.log._debug(f'Hero map persent: {HERO_MAP_PERSENT}')
		self.log._debug("Calculating return from adventure time")
		from_adv = to_adv - (to_adv * int(HERO_MAP_PERSENT) / 100)
		self.log._debug(f'Return time calculated: {from_adv}')
		self.log._debug("Calculating full adventure time")
		wait = to_adv + from_adv + 20
		self.log._debug(f'All time adventure took + 20 sec: {wait}')
		return wait


async def run_tasks():
	while True:
		try:
			t1 = AtergatisAdventures(
				logfile=ADVENTURES_LOG,
				script_name='Chk_adv',
				village_name=HERO_VILLAGE,
				debug=ADVENTURES_DEBUG,
			)
			# task.log._debug("Something wrong. Restarting script..")
			# task.logout()
			tasks = [t1.adventure_check(), t1.amalive()]
			await asyncio.wait(tasks)
		except Exception as err:
			print(Fore.RED, end='')
			print(str(err))
			print(Fore.WHITE, end='')
			t1.logout()
			time.sleep(10)
	

def main():
	loop = asyncio.get_event_loop()
	loop.run_until_complete(run_tasks())
	loop.close()


if __name__ == '__main__':
	main()