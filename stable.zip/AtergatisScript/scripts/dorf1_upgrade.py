import time
#import random
#import yaml
import os
from colorama import Fore, Back, Style
from var import	*
from AtergatisMain import AtergatisOnline



class AtergatisDorf1(AtergatisOnline):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisDorf1' initialized")
		# self.village_name, self.village_link, self.target_level = self._get_dorf1_queue()
		self._get_dorf1_queue()
		self.log.village_name = self.village_name
		self.log._debug("Village link retreived from '_get_village_link' function: " + self.village_link)


	def _get_dorf1_queue(self):
		dorf1_data = self.get_data()['build_dorf1']
		self.village_name = dorf1_data["village_name"]
		self.target_level = dorf1_data["target_level"]
		self.village_link = self._get_village_link(self.village_name)


	def upgrade_dorf1(self):
		min_res = ''
		k = 0

		while True:
			if k < 18:
				self.driver.get(self.village_link)
				hz_massiv, res_lvls = self._get_hz_massiv()
				q_status = self._check_building_queue()	
				if q_status != 'd1_busy' and q_status != 'all_busy':
					self.log._debug(f"Queue status: {q_status}")
					for res in hz_massiv:									
						if int(res['level']) == min(res_lvls):
							field_num = res['num']
							self.log._debug(f"Field num to upgrade: {field_num}")
							link = FIELD_LINK + field_num
							try:
								wait = self.upgrade_field(link, target_level=self.target_level)
								if wait == 315548:
									k += 1
									#time.sleep(1)
									self.log._debug(f"{k} fields are MAX level. {18-k} left.")
									continue
								else:
									self.log._debug(f'Sleeping {wait} seconds.')
									#self.driver.get(DORF2_LINK)
									time.sleep(wait)
									break
							except Exception as err:
								self.log._info(str(err))
								self.log._info(f'ERROR. Unable to upgrade field number {field_num}')
								k += 1
								time.sleep(10)
								break
						else:
							self.log._debug(f"Skipping field num {int(res['num'])}. Not lowest level.")
							continue
				else: # q_status
					self.driver.get(DORF2_LINK)
					self.log._info(f'Waiting for building queue. Sleeping {BUILDING_SLEEP}')
					time.sleep(BUILDING_SLEEP)
			else:
				self.log._debug("Function upgrade_dorf1 returned 315548")
				return 315548


	def _get_hz_massiv(self):
		hz_massiv = []
		res_lvls = []
		for res in range(1,19):
			field = {}
			field['num'] = str(res)
			field['level'] = self.driver.find_element_by_css_selector("#village_map > div:nth-child(" + str(int(res) + 1) + ") > div").text
			if not field['level']:
				field['level'] = 0
			res_lvls.append(int(field['level']))
			hz_massiv.append(field)
		self.log._debug(f"Field/level: {hz_massiv}")
		return hz_massiv, set(res_lvls)


def main():
	while True:
		try:
			task = AtergatisDorf1(
				logfile=UPGRADE_LOG,
				script_name='dorf1',
				debug=BUILD_DEBUG,
			)
			if task.upgrade_dorf1() == 315548:
				task.log._info('All resources fields are MAX level.')
				msg = f"{USERNAME}\nVilla: {task.village_name}\n{task.script_name}\nAll resources fields are MAX level.".replace('_', '-')
				task.tbot(msg)
				task.logout()
				break
			task.log._debug("Something wrong. Restarting script..")

		except Exception as err:
			print(str(err))
			time.sleep(10)

if __name__ == '__main__':
	main()
