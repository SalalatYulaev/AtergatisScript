import time
from colorama import Fore, Back, Style
from var import	*
from AtergatisMain import AtergatisOnline
import random
import asyncio
from datetime import datetime



script_name = 'Bandag'
logfile = "Bandages.txt"



class AtergatisBandages(AtergatisOnline):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisBandages' initialized")
		self.mon_file = BANDAGES_MON['file']
		self.check_mon_file()
		# self.buy_bandages()


	async def buy_bandages(self):
		if TARGET_BANDAGES == 'big':
			while True:
				self.bid_big()
				self.log._info(f"Sleeping {BANDAGES_SLEEP}")
				await asyncio.sleep(BANDAGES_SLEEP)
		if TARGET_BANDAGES == 'small':
			while True:
				self.bid_small()
				self.log._info(f"Sleeping {BANDAGES_SLEEP}")
				await asyncio.sleep(BANDAGES_SLEEP)
		if TARGET_BANDAGES == 'all':
			while True:
				self.bid_all()
				self.log._info(f"Sleeping {BANDAGES_SLEEP}")
				await asyncio.sleep(BANDAGES_SLEEP)


	def bid_big(self):
		self.driver.get("http://tx" + SPEED + ".atergatis.com/hero_auction.php?action=buy&filter=8")
		self.make_bid("BIG")


	def bid_small(self):		
		self.driver.get("http://tx" + SPEED + ".atergatis.com/hero_auction.php?action=buy&filter=7")
		self.make_bid("SMALL")		


	def make_bid(self, kind):
		k = 0
		for i in range (1,40):
			rand = random.randrange(BANDAGES_MIN_BID,BANDAGES_MAX_BID)
			try:
				self.driver.find_element_by_css_selector("#auction > table > tbody > tr:nth-child(" + str(i) + ") > td.bid > a").click()
				self.driver.find_element_by_css_selector("input.maxBid.text").clear()
				self.driver.find_element_by_css_selector("input.maxBid.text").send_keys(rand)
				self.driver.find_element_by_css_selector("div.submitBid").click()
				k +=1
				time.sleep(1)
			except Exception:
				continue
		self.log._info(str(k) + f" {kind} bids done")


	def bid_all(self):
		self.bid_big()
		self.bid_small()


async def run_tasks():
	while True:
		try:
			t1 = AtergatisBandages(
				logfile=BANDAGES_LOG,
				script_name='bandages',
				debug=BANDAGES_DEBUG,
			)
			# task.log._debug("Something wrong. Restarting script..")
			# task.logout()
			tasks = [t1.buy_bandages(), t1.amalive()]
			await asyncio.wait(tasks)
		except Exception as err:
			print(Fore.RED, end='')
			print(str(err))
			print(Fore.WHITE, end='')
			time.sleep(10)
	

def main():
	loop = asyncio.get_event_loop()
	loop.run_until_complete(run_tasks())
	loop.close()


if __name__ == '__main__':
	main()
