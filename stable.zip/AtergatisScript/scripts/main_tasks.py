from var import *
import sys
from subprocess import Popen


s1 = {'overres': OVERRES_SCRIPT}
s2 = {'attacks': ATTACKS_SCRIPT}
s3 = {'adventures': ADVENTURES_SCRIPT}
s4 = {'dorf1': D1_UPGRADE_SCRIPT}
s5 = {'dorf2': D2_UPGRADE_SCRIPT}
# s6 = {'', }
# s7 = {'', }
scripts = [s1, s2, s3, s4, s5]


with open("data_tasks.yaml") as f:
	for line in f:
		if line and not line.startswith('#'):
			for script in scripts:
				for key, value in script.items():
					if key in line:
						Popen([sys.executable, value])