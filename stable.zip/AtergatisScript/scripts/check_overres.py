import time
import re
from colorama import init
from colorama import Fore, Back, Style

from var import	*
from AtergatisMain import AtergatisOnline


# Colorama
init()


class AtergatisOverres(AtergatisOnline):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisOverres' initialized")
		self.village_name, self.storage = self.get_info()
		self.log.village_name = self.village_name
		self.village_link = self._get_village_link(self.village_name)
		self.log._debug("Village link retreived from '_get_village_link' function: " + self.village_link)
		self.infinit_check_overres()


	def get_info(self):
		regexp = r"village_name: (\S+),\s+overres,\s+(\S+)"
		try:
			with open(INFO_FILE) as f:
				return re.search(regexp, f.read()).groups()
		except Exception as err:
			print(Fore.RED, end='')
			self.log._info(str(err))
			print(Fore.WHITE, end='')


	def infinit_check_overres(self):
		self.log._debug("Started infinit_check_overres function")
		while True:
			try:
				self.log._debug("Opening village link")
				self.driver.get(self.village_link)
				time.sleep(1)
				full = False
				self.log._debug(f"Changing full to false: {full}")	
				self.log._debug("Opening dorf 2 link")		
				self.driver.get(DORF2_LINK)
				time.sleep(1)

				self.log._debug(f"Target storage to check: {self.storage}")				
				if self.storage == 'gr':
					self.handle_gr()
				if self.storage == 'wh':
					self.handle_wh()
				self.log._debug(f"sleeping {OVERRES_SLEEP}")
				time.sleep(OVERRES_SLEEP)

			except Exception as err:
				print(Fore.RED, end='')
				self.log._info(str(err))
				print(Fore.WHITE, end='')
				self.log._info("Sleeping 30")
				time.sleep(30)


	def handle_gr(self):
		self.log._debug("Started handle_gr function")
		self.log._debug("Checking resources:")
		wood, clay, iron, crop = self._check_resources()
		self.log._debug(f"{wood}, {clay}, {iron}, {crop}")
		main_resources = [wood, clay, iron]
		if self.is_gr_full(crop):
			if self.is_wh_full(main_resources):
				print(Fore.RED, end='')
				self.log._info("WH and GR are FULL. Check and handle.")
				print(Fore.WHITE, end='')
				self.tbot(f"{USERNAME}, WH and GR are FULL. Check and handle.")
			else:
				print(Fore.RED, end='')
				self.log._info(f'GR is FULL. Redistributing res.')
				print(Fore.WHITE, end='')
				self.tbot(f"{USERNAME}, GR is FULL. Redistributing res.")
				self.redistr_res()



	def handle_wh(self):
		self.log._debug("Started handle_wh function")
		self.log._debug("Checking resources:")
		wood, clay, iron, crop = self._check_resources()
		self.log._debug(f"{wood}, {clay}, {iron}, {crop}")
		main_resources = [wood, clay, iron]
		if self.is_wh_full(main_resources):
			print(Fore.RED, end='')
			self.log._info("WH is FULL. Training caesaris in GR stable.")
			print(Fore.WHITE, end='')
			self.tbot(f"{USERNAME}, WH is FULL. Training caesaris in GR stable.")
			self.train_all_big_caesaris()



def main():
	while True:
		try:
			task = AtergatisOverres(
				logfile=OVERRES_LOG,
				script_name='chk_res',
				debug=OVERRES_DEBUG,
			)
			task.log._debug("Something wrong. Restarting script..")
			task.logout()
		except Exception as err:
			print(Fore.RED, end='')
			print(str(err))
			print(Fore.WHITE, end='')
			time.sleep(10)
			

if __name__ == '__main__':
	main()

