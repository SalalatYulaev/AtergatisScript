import sys
import subprocess
from datetime import datetime
from var import	*
from AtergatisMain import Atergatis



class CheckAttacksInfo(Atergatis):
	def _get_check_villages(self):
		return self.get_data()['check_attacks']


	def script_starter(self):
		for villa in self._get_check_villages():
			subprocess.Popen([sys.executable, ATTACKS_HANDLER, villa])


if __name__ == '__main__':
	task = CheckAttacksInfo(logfile=ATTACKS_LOG)
	task.script_starter()
