import time
import re
import sys
import subprocess
from colorama import init
from colorama import Fore, Back, Style
from var import	*
from AtergatisMain import AtergatisOnline


# Colorama
init()


class AtergatisAttacks(AtergatisOnline):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisAttacks' initialized")
		self.get_info()
		self.log.village_name = self.village_name
		self.village_link = self._get_village_link(self.village_name)
		self.log._debug("Village link retreived from '_get_village_link' function: " + self.village_link)
		self.infinit_check_attacks()


	def get_info(self):
		regexp = r"village_name: (\S+),\s+attacks"
		try:
			with open(INFO_FILE) as f:
				self.village_name = re.search(regexp, f.read()).group(1)
		except Exception as err:
			print(Fore.RED, end='')
			self.log._info(str(err))
			print(Fore.WHITE, end='')


	def infinit_check_attacks(self):
		arrival = ''
		self.log._debug("Opening village link")
		self.driver.get(self.village_link)
		while True:
			try:
				self.log._debug("Opening attacks_on_me link")
				self.driver.get(ATTACKS_ON_ME_LINK)
				time.sleep(1)
				selector = "#build > span"
				self.log._debug("Checking attacks")
				result = self.driver.find_element_by_css_selector(selector).text
				if result == 'No incoming troops':
					self.log._info(f'{result}. Waiting {ATTACKS_SLEEP}')
					time.sleep(ATTACKS_SLEEP)

			except Exception as err:
				self.log._debug(f"Exception: {err}")
				self.log._debug("Retrieving attackers village name")
				src_village_name = self.driver.find_element_by_css_selector("#build > table > thead > tr > td.role > a").text
				self.log._debug(f"{src_village_name}")
				self.log._debug("Retrieving arrival")
				src_arrival = self.driver.find_element_by_css_selector("#build > table > tbody.infos > tr > td > div.at > span:nth-child(1)").text
				self.log._debug(f"{src_arrival}")
				regexp = r'Arrival at (\d+\:\d+\:\d+)'
				self.log._debug("Modifieng arrival")
				src_arrival = re.search(regexp, src_arrival).group(1)
				self.log._debug(f"{src_arrival}")
				self.log._debug("Retrieving time remain")
				time_remain = self.driver.find_element_by_css_selector("#timer1").text
				self.log._debug(f"{time_remain}")
				self.log._debug("Clicking attacers village button")
				pidor_village_button = self.driver.find_element_by_css_selector("#build > table > thead > tr > td.role > a").click()
				self.log._debug("Retrieving attackers Name")
				src_name = self.driver.find_element_by_css_selector("#village_info > tbody > tr:nth-child(3) > td > a").text
				self.log._debug(f"{src_name}")

				self.tbot("ATTACK", level='pzdc')
				if arrival != src_arrival:
					print(Back.RED, end='')
					#print(Fore.BLACK, end='')
					self.log._info('======= ATTACK ==========================')
					#self.log._info(f'Account:  {USERNAME}')
					self.log._info(f'Attacker: {src_name}')
					self.log._info(f'Village:  {src_village_name}')
					self.log._info(f'Arrival:  {src_arrival}')
					self.log._info(f'Remain:   {time_remain}')
					self.log._info('=========================================')
					print(Back.BLACK, end='')
					print(Fore.WHITE, end='')
					arrival = src_arrival
					self.tbot(f"Attacker: {src_name}\nVillage:  {src_village_name}\nArrival:  {src_arrival}\nRemain:   {time_remain}", level='pzdc')
					self.log._info('Executing Save Troops Script.')
					subprocess.Popen([sys.executable, SAVE_TROOPS_SCRIPT, self.village_name, time_remain, src_village_name, src_arrival, src_name])
					self.log._info(f'Sleeping {ATTACKS_SLEEP}')
					time.sleep(ATTACKS_SLEEP)
				else:
					self.log._info(f'TA ZHE ATAKA. Sleeping {ATTACKS_SLEEP}')
					time.sleep(ATTACKS_SLEEP)




def main():
	while True:
		try:
			task = AtergatisAttacks(
				logfile=ATTACKS_LOG,
				script_name='attacks',
				debug=ATTACKS_DEBUG,
			)
			task.log._debug("Something wrong. Restarting script..")
			task.logout()
		except Exception as err:
			print(Fore.RED, end='')
			print(str(err))
			print(Fore.WHITE, end='')
			time.sleep(10)
			

if __name__ == '__main__':
	main()

