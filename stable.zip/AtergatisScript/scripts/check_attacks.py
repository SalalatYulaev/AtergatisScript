import sys
import subprocess
from datetime import datetime
from var import	*
from AtergatisMain import Atergatis
from colorama import Fore, Back, Style
import time


class CheckAttacksInfo(Atergatis):
	def _get_check_villages(self):
		return self.get_data()['check_attacks']


	def script_starter(self):
		for villa in self._get_check_villages():
			subprocess.Popen([sys.executable, ATTACKS_HANDLER, villa])


if __name__ == '__main__':
	try:
		task = CheckAttacksInfo(logfile=ATTACKS_LOG)
		task.script_starter()
	except Exception as err:
		print(Fore.RED, end='')
		print(str(err))
		print(Fore.WHITE, end='')
		t1.logout()
		time.sleep(10)
