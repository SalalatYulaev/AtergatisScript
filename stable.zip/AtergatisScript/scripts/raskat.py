import time
import re
from var import	*
from AtergatisMain import AtergatisOnline
from selenium.webdriver.support.ui import Select



class AtergatisRaskat(AtergatisOnline):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisRaskat' initialized")
		self._get_raskat_data()
		self.log.village_name = self.village_name
		self.village_link = self._get_village_link(self.village_name)
		self.log._debug("Village link retreived from '_get_village_link' function: " + self.village_link)
		self.decision()


	def _get_raskat_data(self):
		self.log._debug("Started _get_raskat_data function")
		with open(RASKAT_DATA_FILE) as f:
			data = yaml.safe_load(f)
		self.log._debug(f"{data}")
		self.village_name = data['source_village']
		self.target_village_id = data['target_village_id']
		self.waves = data['waves']
		self.troops_type = data['troops_type']
		self.troops_in_wave = data['troops_in_wave']
		self.catas_in_wave = data['catas_in_wave']


	def decision(self):
		tabs = self.opening_tabs()
		decision = ''
		while True:
			if decision == 'ok':
				self.log._debug(f"Decision is OK. Starting PIZDA!")
				for tab in tabs:
					try:
						self.log._debug(f"Switching to tab {tab}")
						self.driver.switch_to.window(tab)
						self.log._debug(f"Clicking OK")
						self.driver.find_element_by_css_selector("#btn_ok > div > div.button-content").click()
					except Exception as err:
						self.log._debug(f"{err}")
						continue
				self.log._info("=" * 50)
				print("KOMY-TO PIZDA )))")
				break
			if decision == 'q':
				self.log._debug(f"Decision is Q")
				confirm = ''
				while True:
					if confirm == 'y':
						self.log._debug(f"Confirm is Y")
						break
					if confirm == 'n':
						self.log._debug(f"Confirm is N. Exiting.")
						decision = ''
						break
					else:
						self.log._debug(f"Are u sure?")
						confirm = input("Are you sure? Y/N: ").lower()
				if confirm == 'y':
					self.log._info(f"You confirmed CANCEL(((")
					self.log._info("=" * 50)
					break
			else:
				decision = input('Print "OK" when ready or "Q" to cancel: ').lower()


	def opening_tabs(self):
		self.log._debug(f"Started opening_tabs function")
		tabs = []
		self.log._debug(f"Opening village link")		
		self.driver.get(self.village_link)
		# time.sleep(1)
		for i in range(int(self.waves)):
			self.log._debug(f"Opening tab {i+1}")
			self.driver.execute_script("window.open('','_blank');")
			tab = self.driver.window_handles[i + 1]
			self.log._debug(f"Switching to tab {i+1}")	
			self.driver.switch_to.window(tab)
			tabs.append(tab)
			self.log._debug(f"Opening target village link")
			self.driver.get(SEND_TROOPS_LINK + self.target_village_id)

			if self.troops_type == 'legs':
				self.driver.find_element_by_css_selector("#troops > tbody > tr:nth-child(1) > td.line-first.column-first.large > input").send_keys(str(self.troops_in_wave))	#legs amount
			if self.troops_type == 'imps':
				self.driver.find_element_by_css_selector("#troops > tbody > tr:nth-child(3) > td.line-last.column-first.large > input").send_keys(str(self.troops_in_wave))		#Imps amount
			if self.troops_type == 'imper_horses':
				self.driver.find_element_by_css_selector("#troops > tbody > tr:nth-child(2) > td:nth-child(2) > input").send_keys(str(self.troops_in_wave))	#Imper Horses amount
			if self.troops_type == 'caesaris':
				self.driver.find_element_by_css_selector("#troops > tbody > tr:nth-child(3) > td:nth-child(2) > input").send_keys(str(self.troops_in_wave))	#Caesaris amount

			self.log._debug(f"Sending Catas amount {self.catas_in_wave}")
			self.driver.find_element_by_css_selector("#troops > tbody > tr:nth-child(2) > td.regular > input").send_keys(str(self.catas_in_wave))
			self.log._debug(f"Clicking Normal Attack button")
			self.driver.find_element_by_css_selector("#build > form > div.option > label:nth-child(3) > input").click()	# Normal Attack
			self.log._debug(f"Clicking Confirm")
			self.driver.find_element_by_css_selector("#btn_ok > div > div.button-content").click()	# Confirm
			#self.driver.send_keys(keys.RETURN)
			self.log._debug(f"Selecting catas target random")
			select = Select(self.driver.find_element_by_css_selector("[name='ctar2']"))
			select.select_by_value("0")
			# select.submit()
			# self.log._debug(f"Clicking Submit ??")
			# self.driver.find_element_by_css_selector("#build > form > table.troop_details > tbody.cata > tr > td > select:nth-child(2)")
		print('\n\nCATAS ARE S NADROCHENNYM!!\n\n')
		print("=" * 30)
		print("   ЧЕКЛИСТ! ")
		print("0. % АТАКИ ГЕРОЯ БЛЯТЬ (20%) ")
		print("1. ПАЛКА НА ГЕРОЯ")
		print("2. ПОВЯЗКИ")
		print("3. ШЛЕМ (КОНИ, ПЕХОТА)")
		print("=" * 30 + '\n\n')
		self.log._debug(f"Setting page timeout 0.2 sec")
		self.driver.set_page_load_timeout('0.2')
		return tabs


def main():
	try:
		task = AtergatisRaskat(
			logfile=RASKAT_LOG,
			script_name='raskat',
			debug=RASKAT_DEBUG,
		)
		task.log._debug("Logging out")
		task.logout()
	except Exception as err:
		print(str(err))
		time.sleep(10)
			

if __name__ == '__main__':
	main()