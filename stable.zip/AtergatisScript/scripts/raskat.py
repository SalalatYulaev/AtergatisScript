import time
import re
from var import	*
from AtergatisMain import AtergatisOnline
from selenium.webdriver.support.ui import Select




class AtergatisRaskat(AtergatisOnline):
	raskat_data_file = RASKAT_FILE
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisRaskat' initialized")
		self._get_raskat_data()
		self.log.village_name = self.village_name
		self.village_link = self._get_village_link(self.village_name)
		self.log._debug("Village link retreived from '_get_village_link' function: " + self.village_link)
		self.decision()	


	def _get_raskat_data(self):
		self.log._debug("Starting parsing raskat.txt")
		with open(self.raskat_data_file) as f:
			data = f.read()
			self.village_name = re.search(r"From village:\s+(\S+)", data).group(1)
			self.log._debug(f"Village name: {self.village_name}")
			self.dst_village = re.search(r"Target village ID:\s+(\S+)", data).group(1)
			self.log._debug(f"Target village: {self.dst_village}")
			self.waves = re.search(r"Waves:\s+(\S+)", data).group(1)
			self.log._debug(f"Waves: {self.waves}")
			self.horses_amnt = re.search(r"Horses in wave:\s+(\S+)", data).group(1)
			self.log._debug(f"Horses amount: {self.horses_amnt}")
			self.catas_amnt = re.search(r"Catas in wave:\s+(\S+)", data).group(1)
			self.log._debug(f"Cats amount: {self.catas_amnt}")


	def opening_tabs(self):
		self.log._debug(f"Started raskat function")
		tabs = []		
		target_link = SEND_TROOPS_LINK + self.dst_village
		self.log._debug(f"Opening village link")		
		self.driver.get(self.village_link)
		time.sleep(1)
		for i in range(int(self.waves)):
			self.log._debug(f"Opening tab {i+1}")
			self.driver.execute_script("window.open('','_blank');")
			tab = self.driver.window_handles[i + 1]
			self.log._debug(f"Switching to tab {i+1}")	
			self.driver.switch_to.window(tab)
			tabs.append(tab)
			self.log._debug(f"Opening target village link")
			self.driver.get(target_link)
			#troops > tbody > tr:nth-child(2) > td.regular > input			
			#self.driver.find_element_by_css_selector("#troops > tbody > tr:nth-child(1) > td.line-first.column-first.large > input").send_keys(str(self.horses_amnt))	#legs amount
			self.log._debug(f"Sending Horses amount {self.horses_amnt}")
			self.driver.find_element_by_css_selector("#troops > tbody > tr:nth-child(3) > td.line-last.column-first.large > input").send_keys(str(self.horses_amnt))	#Imps amount
			#self.driver.find_element_by_css_selector("#troops > tbody > tr:nth-child(2) > td:nth-child(2) > input").send_keys(str(self.horses_amnt))					#Imper Hprses amount
			#self.driver.find_element_by_css_selector("#troops > tbody > tr:nth-child(3) > td:nth-child(2) > input").send_keys(str(self.horses_amnt))					#Caesaris amount
			self.log._debug(f"Sending Catas amount {self.catas_amnt}")
			self.driver.find_element_by_css_selector("#troops > tbody > tr:nth-child(2) > td.regular > input").send_keys(str(self.catas_amnt))
			self.log._debug(f"Clicking Normal Attack button")
			self.driver.find_element_by_css_selector("#build > form > div.option > label:nth-child(3) > input").click()	# Normal Attack
			self.log._debug(f"Clicking Confirm")
			self.driver.find_element_by_css_selector("#btn_ok > div > div.button-content").click()	# Confirm
			#self.driver.send_keys(keys.RETURN)
			self.log._debug(f"Selecting catas target random")
			select = Select(self.driver.find_element_by_css_selector("[name='ctar2']"))
			select.select_by_value("0")
			#select.submit()
			self.log._debug(f"Clicking Submit")
			self.driver.find_element_by_css_selector("#build > form > table.troop_details > tbody.cata > tr > td > select:nth-child(2)")
		print('\n\nCATAS ARE S NADROCHENNYM!!\n\n')
		print("=" * 30)
		print("   ЧЕКЛИСТ! ")
		print("0. % АТАКИ ГЕРОЯ БЛЯТЬ (20%) ")
		print("1. ПАЛКА НА ГЕРОЯ")
		print("2. ПОВЯЗКИ")
		print("3. ШЛЕМ (КОНИ, ПЕХОТА)")
		print("=" * 30 + '\n\n')
		self.log._debug(f"Setting page timeout 0.2 sec")
		self.driver.set_page_load_timeout('0.2')
		return tabs


	def decision(self):
		tabs = self.opening_tabs()
		decision = ''
		while True:
			if decision == 'ok':
				self.log._debug(f"Decision is OK. Starting PIZDA!")
				for tab in tabs:
					try:
						self.log._debug(f"Switching to tab {tab}")
						self.driver.switch_to_window(tab)
						self.log._debug(f"Clicking OK")
						self.driver.find_element_by_css_selector("#btn_ok > div > div.button-content").click()
					except Exception as err:
						self.log._debug(f"{err}")
						continue
				self.log._info("=" * 50)
				print("KOMY-TO PIZDA )))")
				break
			if decision == 'q':
				self.log._debug(f"Decision is Q")
				confirm = ''
				while True:
					if confirm == 'y':
						self.log._debug(f"Confirm is Y")
						break
					if confirm == 'n':
						self.log._debug(f"Confirm is N. Exiting.")
						decision = ''
						break
					else:
						self.log._debug(f"Are u sure?")
						confirm = input("Are you sure? Y/N: ").lower()
				if confirm == 'y':
					self.log._debug(f"You confirmed CANCEL(((")
					self.log._info("=" * 50)
					print("OTMENA")
					break
			else:
				decision = input('Prink "OK" when ready or "Q" to cancel: ').lower()



def main():
	try:
		task = AtergatisRaskat(
			logfile=RASKAT_LOG,
			script_name='raskat',
			debug=RASKAT_DEBUG,
		)
		task.log._debug("Logging out")
		task.logout()
	except Exception as err:
		print(str(err))
		time.sleep(10)
			

if __name__ == '__main__':
	main()




