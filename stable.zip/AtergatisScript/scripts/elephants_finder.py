import time
import re
from colorama import init, Fore, Back, Style
from var import	*
from AtergatisMain import AtergatisOnline




class AtergatisElephants(AtergatisOnline):
	elephants_list = "elephants.txt"
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.log._debug(f'Started script {self.script_name}')
		self.log._debug("Class 'AtergatisElephants' initialized")
		self.find_elephants()


	def find_elephants(self):
		regexp = r'(\d+) Elephant'
		for x in range(-100,101):
			for y in range(-100,101):
				link = COORDS_LINK + f"x={x}&y={y}"
				try:
					self.driver.get(link)
					if "Unoccupied Oasis" in self.driver.find_element_by_css_selector("#content > h1 > span.coordinates.coordinatesWithText > span.coordText").text:
						self.log._debug(f"Found oasis {x}|{y}")
						try:
							self.log._debug("Trying to get troops table")
							table = self.driver.find_element_by_css_selector("#troop_info").text
							self.log._debug(f"Get table successfully\n {table}")
							if "Elephant" in table:
								self.log._debug("Elephants are in table")
								amnt = re.search(regexp, table).group(1)
								self.log._info(f"{amnt} Elephants Found {x}|{y}")
								with open(self.elephants_list, 'a') as f:
									f.write("{:2}|{:<5}{:4}{}\n".format(x, y, amnt, " Elephants Found!"))
							else:
								self.log._debug("No elephants found.")
						except Exception as err:
							self.log._debug(f"{err} on {x}|{y}")
				except Exception as err:
					continue

def main():
	while True:
		try:
			task = AtergatisElephants(
				logfile=ELEPHANTS_LOG,
				script_name='Slony',
				debug=ELEPHANTS_DEBUG,
			)
			task.log._debug("Something wrong. Restarting script..")
			task.logout()
		except Exception as err:
			print(str(err))
			time.sleep(10)
			

if __name__ == '__main__':
	main()


